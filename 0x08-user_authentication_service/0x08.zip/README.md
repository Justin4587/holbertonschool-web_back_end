Readme for building own user authentication service step by step
